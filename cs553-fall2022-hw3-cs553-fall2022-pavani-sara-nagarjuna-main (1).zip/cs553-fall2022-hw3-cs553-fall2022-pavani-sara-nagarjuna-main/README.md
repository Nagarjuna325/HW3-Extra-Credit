### CS553 Cloud Computing Homework 3 Repo
**Illinois Institute of Technology**  

Team Name: cs553-fall2022-pavani-sara-nagarjuna Students:
Sara Ataullah - A20503938 (sataullah@hawk.iit.edu) Pavani Rangineni - A20516359 (prangineni@hawk.iit.edu) Nagarjuna Bolla - A20254548 (nbolla@hawk.iit.edu)
